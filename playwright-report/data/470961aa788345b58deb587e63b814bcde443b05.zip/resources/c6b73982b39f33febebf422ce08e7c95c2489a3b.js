const e={if:{label:"if",snippet:`if (condition) {
	# code
}`,description:"if statement"},ifelse:{label:"ifelse",snippet:`if (condition) {
	# code
} else {
	# else code
}`,description:"if-else statement"},for:{label:"for",snippet:`for (i in 1:10) {
	# code
}`,description:"for loop"},while:{label:"while",snippet:`while (condition) {
	# code
}`,description:"while loop"},function:{label:"function",snippet:`name <- function(args) {
	# code
	return(result)
}`,description:"function definition"},library:{label:"library",snippet:"library(package)",description:"load library"},dataframe:{label:"data.frame",snippet:`data.frame(
	col1 = values1,
	col2 = values2
)`,description:"create data frame"}};export{e as default};
