import{_ as b}from"./PPVm8Dsz.js";var ve=Object.defineProperty,s=(e,t)=>ve(e,"name",{value:t,configurable:!0}),G=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,r)=>(typeof require<"u"?require:t)[r]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')}),we=(()=>{for(var e=new Uint8Array(128),t=0;t<64;t++)e[t<26?t+65:t<52?t+71:t<62?t-4:t*4-205]=t;return r=>{for(var o=r.length,n=new Uint8Array((o-(r[o-1]=="=")-(r[o-2]=="="))*3/4|0),i=0,a=0;i<o;){var l=e[r.charCodeAt(i++)],u=e[r.charCodeAt(i++)],c=e[r.charCodeAt(i++)],m=e[r.charCodeAt(i++)];n[a++]=l<<2|u>>4,n[a++]=u<<4|c>>2,n[a++]=c<<6|m}return n}})();function H(e){return!isNaN(parseFloat(e))&&isFinite(e)}s(H,"_isNumber");function w(e){return e.charAt(0).toUpperCase()+e.substring(1)}s(w,"_capitalize");function D(e){return function(){return this[e]}}s(D,"_getter");var S=["isConstructor","isEval","isNative","isToplevel"],A=["columnNumber","lineNumber"],x=["fileName","functionName","source"],Ee=["args"],ke=["evalOrigin"],T=S.concat(A,x,Ee,ke);function h(e){if(e)for(var t=0;t<T.length;t++)e[T[t]]!==void 0&&this["set"+w(T[t])](e[T[t]])}s(h,"StackFrame");h.prototype={getArgs:s(function(){return this.args},"getArgs"),setArgs:s(function(e){if(Object.prototype.toString.call(e)!=="[object Array]")throw new TypeError("Args must be an Array");this.args=e},"setArgs"),getEvalOrigin:s(function(){return this.evalOrigin},"getEvalOrigin"),setEvalOrigin:s(function(e){if(e instanceof h)this.evalOrigin=e;else if(e instanceof Object)this.evalOrigin=new h(e);else throw new TypeError("Eval Origin must be an Object or StackFrame")},"setEvalOrigin"),toString:s(function(){var e=this.getFileName()||"",t=this.getLineNumber()||"",r=this.getColumnNumber()||"",o=this.getFunctionName()||"";return this.getIsEval()?e?"[eval] ("+e+":"+t+":"+r+")":"[eval]:"+t+":"+r:o?o+" ("+e+":"+t+":"+r+")":e+":"+t+":"+r},"toString")};h.fromString=s(function(e){var t=e.indexOf("("),r=e.lastIndexOf(")"),o=e.substring(0,t),n=e.substring(t+1,r).split(","),i=e.substring(r+1);if(i.indexOf("@")===0)var a=/@(.+?)(?::(\d+))?(?::(\d+))?$/.exec(i,""),l=a[1],u=a[2],c=a[3];return new h({functionName:o,args:n||void 0,fileName:l,lineNumber:u||void 0,columnNumber:c||void 0})},"StackFrame$$fromString");for(k=0;k<S.length;k++)h.prototype["get"+w(S[k])]=D(S[k]),h.prototype["set"+w(S[k])]=(function(e){return function(t){this[e]=!!t}})(S[k]);var k;for(P=0;P<A.length;P++)h.prototype["get"+w(A[P])]=D(A[P]),h.prototype["set"+w(A[P])]=(function(e){return function(t){if(!H(t))throw new TypeError(e+" must be a Number");this[e]=Number(t)}})(A[P]);var P;for(I=0;I<x.length;I++)h.prototype["get"+w(x[I])]=D(x[I]),h.prototype["set"+w(x[I])]=(function(e){return function(t){this[e]=String(t)}})(x[I]);var I,M=h;function J(){var e=/^\s*at .*(\S+:\d+|\(native\))/m,t=/^(eval@)?(\[native code])?$/;return{parse:s(function(r){if(r.stack&&r.stack.match(e))return this.parseV8OrIE(r);if(r.stack)return this.parseFFOrSafari(r);throw new Error("Cannot parse given Error object")},"ErrorStackParser$$parse"),extractLocation:s(function(r){if(r.indexOf(":")===-1)return[r];var o=/(.+?)(?::(\d+))?(?::(\d+))?$/,n=o.exec(r.replace(/[()]/g,""));return[n[1],n[2]||void 0,n[3]||void 0]},"ErrorStackParser$$extractLocation"),parseV8OrIE:s(function(r){var o=r.stack.split(`
`).filter(function(n){return!!n.match(e)},this);return o.map(function(n){n.indexOf("(eval ")>-1&&(n=n.replace(/eval code/g,"eval").replace(/(\(eval at [^()]*)|(,.*$)/g,""));var i=n.replace(/^\s+/,"").replace(/\(eval code/g,"(").replace(/^.*?\s+/,""),a=i.match(/ (\(.+\)$)/);i=a?i.replace(a[0],""):i;var l=this.extractLocation(a?a[1]:i),u=a&&i||void 0,c=["eval","<anonymous>"].indexOf(l[0])>-1?void 0:l[0];return new M({functionName:u,fileName:c,lineNumber:l[1],columnNumber:l[2],source:n})},this)},"ErrorStackParser$$parseV8OrIE"),parseFFOrSafari:s(function(r){var o=r.stack.split(`
`).filter(function(n){return!n.match(t)},this);return o.map(function(n){if(n.indexOf(" > eval")>-1&&(n=n.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g,":$1")),n.indexOf("@")===-1&&n.indexOf(":")===-1)return new M({functionName:n});var i=/((.*".+"[^@]*)?[^@]*)(?:@)/,a=n.match(i),l=a&&a[1]?a[1]:void 0,u=this.extractLocation(n.replace(i,""));return new M({functionName:l,fileName:u[0],lineNumber:u[1],columnNumber:u[2],source:n})},this)},"ErrorStackParser$$parseFFOrSafari")}}s(J,"ErrorStackParser");var Pe=new J,Ie=Pe,v=typeof process=="object"&&typeof process.versions=="object"&&typeof process.versions.node=="string"&&!process.browser,q=v&&typeof module<"u"&&typeof module.exports<"u"&&typeof G<"u"&&typeof __dirname<"u",Se=v&&!q,Ae=typeof Deno<"u",Y=!v&&!Ae,xe=Y&&typeof window=="object"&&typeof document=="object"&&typeof document.createElement=="function"&&"sessionStorage"in window&&typeof importScripts!="function",Oe=Y&&typeof importScripts=="function"&&typeof self=="object";typeof navigator=="object"&&typeof navigator.userAgent=="string"&&navigator.userAgent.indexOf("Chrome")==-1&&navigator.userAgent.indexOf("Safari")>-1;var N=typeof read=="function"&&typeof load=="function",Z,V,K,W,$;async function j(){if(!v||(Z=(await b(async()=>{const{default:i}=await import("./D7Ct-6yo.js").then(a=>a._);return{default:i}},[],import.meta.url)).default,W=await b(()=>import("./D7Ct-6yo.js").then(i=>i._),[],import.meta.url),$=await b(()=>import("./D7Ct-6yo.js").then(i=>i._),[],import.meta.url),K=(await b(async()=>{const{default:i}=await import("./D7Ct-6yo.js").then(a=>a._);return{default:i}},[],import.meta.url)).default,V=await b(()=>import("./D7Ct-6yo.js").then(i=>i._),[],import.meta.url),z=V.sep,typeof G<"u"))return;let e=W,t=await b(()=>import("./D7Ct-6yo.js").then(i=>i._),[],import.meta.url),r=await b(()=>import("./D7Ct-6yo.js").then(i=>i._),[],import.meta.url),o=await b(()=>import("./D7Ct-6yo.js").then(i=>i._),[],import.meta.url),n={fs:e,crypto:t,ws:r,child_process:o};globalThis.require=function(i){return n[i]}}s(j,"initNodeModules");function Q(e,t){return V.resolve(t||".",e)}s(Q,"node_resolvePath");function X(e,t){return t===void 0&&(t=location),new URL(e,t).toString()}s(X,"browser_resolvePath");var R;v?R=Q:N?R=s(e=>e,"resolvePath"):R=X;var z;v||(z="/");function ee(e,t){return e.startsWith("file://")&&(e=e.slice(7)),e.includes("://")?{response:fetch(e)}:{binary:$.readFile(e).then(r=>new Uint8Array(r.buffer,r.byteOffset,r.byteLength))}}s(ee,"node_getBinaryResponse");function te(e,t){if(e.startsWith("file://")&&(e=e.slice(7)),e.includes("://"))throw new Error("Shell cannot fetch urls");return{binary:Promise.resolve(new Uint8Array(readbuffer(e)))}}s(te,"shell_getBinaryResponse");function re(e,t){let r=new URL(e,location);return{response:fetch(r,t?{integrity:t}:{})}}s(re,"browser_getBinaryResponse");var L;v?L=ee:N?L=te:L=re;async function ie(e,t){let{response:r,binary:o}=L(e,t);if(o)return o;let n=await r;if(!n.ok)throw new Error(`Failed to load '${e}': request failed.`);return new Uint8Array(await n.arrayBuffer())}s(ie,"loadBinaryFile");var O;if(xe)O=s(async e=>await import(e),"loadScript");else if(Oe)O=s(async e=>{try{globalThis.importScripts(e)}catch(t){if(t instanceof TypeError)await import(e);else throw t}},"loadScript");else if(v)O=ae;else if(N)O=load;else throw new Error("Cannot determine runtime environment");async function ae(e){e.startsWith("file://")&&(e=e.slice(7)),e.includes("://")?K.runInThisContext(await(await fetch(e)).text()):await import(Z.pathToFileURL(e).href)}s(ae,"nodeLoadScript");async function ne(e){if(v){await j();let t=await $.readFile(e,{encoding:"utf8"});return JSON.parse(t)}else if(N){let t=read(e);return JSON.parse(t)}else return await(await fetch(e)).json()}s(ne,"loadLockFile");async function oe(){if(q)return __dirname;let e;try{throw new Error}catch(o){e=o}let t=Ie.parse(e)[0].fileName;if(v&&!t.startsWith("file://")&&(t=`file://${t}`),Se){let o=await b(()=>import("./D7Ct-6yo.js").then(n=>n._),[],import.meta.url);return(await b(async()=>{const{fileURLToPath:n}=await import("./D7Ct-6yo.js").then(i=>i._);return{fileURLToPath:n}},[],import.meta.url)).fileURLToPath(o.dirname(t))}let r=t.lastIndexOf(z);if(r===-1)throw new Error("Could not extract indexURL path from pyodide module location");return t.slice(0,r)}s(oe,"calculateDirname");function se(e){return e.substring(0,e.lastIndexOf("/")+1)||globalThis.location?.toString()||"."}s(se,"calculateInstallBaseUrl");function le(e){let t=e.FS,r=e.FS.filesystems.MEMFS,o=e.PATH,n={DIR_MODE:16895,FILE_MODE:33279,mount:s(function(i){if(!i.opts.fileSystemHandle)throw new Error("opts.fileSystemHandle is required");return r.mount.apply(null,arguments)},"mount"),syncfs:s(async(i,a,l)=>{try{let u=n.getLocalSet(i),c=await n.getRemoteSet(i),m=a?c:u,p=a?u:c;await n.reconcile(i,m,p),l(null)}catch(u){l(u)}},"syncfs"),getLocalSet:s(i=>{let a=Object.create(null);function l(m){return m!=="."&&m!==".."}s(l,"isRealDir");function u(m){return p=>o.join2(m,p)}s(u,"toAbsolute");let c=t.readdir(i.mountpoint).filter(l).map(u(i.mountpoint));for(;c.length;){let m=c.pop(),p=t.stat(m);t.isDir(p.mode)&&c.push.apply(c,t.readdir(m).filter(l).map(u(m))),a[m]={timestamp:p.mtime,mode:p.mode}}return{type:"local",entries:a}},"getLocalSet"),getRemoteSet:s(async i=>{let a=Object.create(null),l=await Fe(i.opts.fileSystemHandle);for(let[u,c]of l)u!=="."&&(a[o.join2(i.mountpoint,u)]={timestamp:c.kind==="file"?new Date((await c.getFile()).lastModified):new Date,mode:c.kind==="file"?n.FILE_MODE:n.DIR_MODE});return{type:"remote",entries:a,handles:l}},"getRemoteSet"),loadLocalEntry:s(i=>{let a=t.lookupPath(i).node,l=t.stat(i);if(t.isDir(l.mode))return{timestamp:l.mtime,mode:l.mode};if(t.isFile(l.mode))return a.contents=r.getFileDataAsTypedArray(a),{timestamp:l.mtime,mode:l.mode,contents:a.contents};throw new Error("node type not supported")},"loadLocalEntry"),storeLocalEntry:s((i,a)=>{if(t.isDir(a.mode))t.mkdirTree(i,a.mode);else if(t.isFile(a.mode))t.writeFile(i,a.contents,{canOwn:!0});else throw new Error("node type not supported");t.chmod(i,a.mode),t.utime(i,a.timestamp,a.timestamp)},"storeLocalEntry"),removeLocalEntry:s(i=>{var a=t.stat(i);t.isDir(a.mode)?t.rmdir(i):t.isFile(a.mode)&&t.unlink(i)},"removeLocalEntry"),loadRemoteEntry:s(async i=>{if(i.kind==="file"){let a=await i.getFile();return{contents:new Uint8Array(await a.arrayBuffer()),mode:n.FILE_MODE,timestamp:new Date(a.lastModified)}}else{if(i.kind==="directory")return{mode:n.DIR_MODE,timestamp:new Date};throw new Error("unknown kind: "+i.kind)}},"loadRemoteEntry"),storeRemoteEntry:s(async(i,a,l)=>{let u=i.get(o.dirname(a)),c=t.isFile(l.mode)?await u.getFileHandle(o.basename(a),{create:!0}):await u.getDirectoryHandle(o.basename(a),{create:!0});if(c.kind==="file"){let m=await c.createWritable();await m.write(l.contents),await m.close()}i.set(a,c)},"storeRemoteEntry"),removeRemoteEntry:s(async(i,a)=>{await i.get(o.dirname(a)).removeEntry(o.basename(a)),i.delete(a)},"removeRemoteEntry"),reconcile:s(async(i,a,l)=>{let u=0,c=[];Object.keys(a.entries).forEach(function(d){let f=a.entries[d],y=l.entries[d];(!y||t.isFile(f.mode)&&f.timestamp.getTime()>y.timestamp.getTime())&&(c.push(d),u++)}),c.sort();let m=[];if(Object.keys(l.entries).forEach(function(d){a.entries[d]||(m.push(d),u++)}),m.sort().reverse(),!u)return;let p=a.type==="remote"?a.handles:l.handles;for(let d of c){let f=o.normalize(d.replace(i.mountpoint,"/")).substring(1);if(l.type==="local"){let y=p.get(f),E=await n.loadRemoteEntry(y);n.storeLocalEntry(d,E)}else{let y=n.loadLocalEntry(d);await n.storeRemoteEntry(p,f,y)}}for(let d of m)if(l.type==="local")n.removeLocalEntry(d);else{let f=o.normalize(d.replace(i.mountpoint,"/")).substring(1);await n.removeRemoteEntry(p,f)}},"reconcile")};e.FS.filesystems.NATIVEFS_ASYNC=n}s(le,"initializeNativeFS");var Fe=s(async e=>{let t=[];async function r(n){for await(let i of n.values())t.push(i),i.kind==="directory"&&await r(i)}s(r,"collect"),await r(e);let o=new Map;o.set(".",e);for(let n of t){let i=(await e.resolve(n)).join("/");o.set(i,n)}return o},"getFsHandles"),Re=we("AGFzbQEAAAABDANfAGAAAW9gAW8BfwMDAgECByECD2NyZWF0ZV9zZW50aW5lbAAAC2lzX3NlbnRpbmVsAAEKEwIHAPsBAPsbCwkAIAD7GvsUAAs="),Le=(async function(){if(!(globalThis.navigator&&(/iPad|iPhone|iPod/.test(navigator.userAgent)||navigator.platform==="MacIntel"&&typeof navigator.maxTouchPoints<"u"&&navigator.maxTouchPoints>1)))try{let e=await WebAssembly.compile(Re);return await WebAssembly.instantiate(e)}catch(e){if(e instanceof WebAssembly.CompileError)return;throw e}})();async function ue(){let e=await Le;if(e)return e.exports;let t=Symbol("error marker");return{create_sentinel:s(()=>t,"create_sentinel"),is_sentinel:s(r=>r===t,"is_sentinel")}}s(ue,"getSentinelImport");function ce(e){let t={noImageDecoding:!0,noAudioDecoding:!0,noWasmDecoding:!1,preRun:he(e),print:e.stdout,printErr:e.stderr,onExit(r){t.exitCode=r},thisProgram:e._sysExecutable,arguments:e.args,API:{config:e},locateFile:s(r=>e.indexURL+r,"locateFile"),instantiateWasm:_e(e.indexURL)};return t}s(ce,"createSettings");function pe(e){return function(t){let r="/";try{t.FS.mkdirTree(e)}catch(o){console.error(`Error occurred while making a home directory '${e}':`),console.error(o),console.error(`Using '${r}' for a home directory instead`),e=r}t.FS.chdir(e)}}s(pe,"createHomeDirectory");function de(e){return function(t){Object.assign(t.ENV,e)}}s(de,"setEnvironment");function me(e){return e?[async t=>{t.addRunDependency("fsInitHook");try{await e(t.FS,{sitePackages:t.API.sitePackages})}finally{t.removeRunDependency("fsInitHook")}}]:[]}s(me,"callFsInitHook");function fe(e){let t=e.HEAPU32[e._Py_Version>>>2],r=t>>>24&255,o=t>>>16&255,n=t>>>8&255;return[r,o,n]}s(fe,"computeVersionTuple");function ye(e){let t=ie(e);return async r=>{r.API.pyVersionTuple=fe(r);let[o,n]=r.API.pyVersionTuple;r.FS.mkdirTree("/lib"),r.API.sitePackages=`/lib/python${o}.${n}/site-packages`,r.FS.mkdirTree(r.API.sitePackages),r.addRunDependency("install-stdlib");try{let i=await t;r.FS.writeFile(`/lib/python${o}${n}.zip`,i)}catch(i){console.error("Error occurred while installing the standard library:"),console.error(i)}finally{r.removeRunDependency("install-stdlib")}}}s(ye,"installStdlib");function he(e){let t;return e.stdLibURL!=null?t=e.stdLibURL:t=e.indexURL+"python_stdlib.zip",[ye(t),pe(e.env.HOME),de(e.env),le,...me(e.fsInit)]}s(he,"getFileSystemInitializationFuncs");function _e(e){if(typeof WasmOffsetConverter<"u")return;let{binary:t,response:r}=L(e+"pyodide.asm.wasm"),o=ue();return function(n,i){return(async function(){n.sentinel=await o;try{let a;r?a=await WebAssembly.instantiateStreaming(r,n):a=await WebAssembly.instantiate(await t,n);let{instance:l,module:u}=a;i(l,u)}catch(a){console.warn("wasm instantiation failed!"),console.warn(a)}})(),{}}}s(_e,"getInstantiateWasmFunc");var Te="0.28.3";function F(e){return e===void 0||e.endsWith("/")?e:e+"/"}s(F,"withTrailingSlash");var U=Te;async function ge(e={}){if(e.lockFileContents&&e.lockFileURL)throw new Error("Can't pass both lockFileContents and lockFileURL");await j();let t=e.indexURL||await oe();t=F(R(t));let r=e;if(r.packageBaseUrl=F(r.packageBaseUrl),r.cdnUrl=F(r.packageBaseUrl??`https://cdn.jsdelivr.net/pyodide/v${U}/full/`),!e.lockFileContents){let p=e.lockFileURL??t+"pyodide-lock.json";r.lockFileContents=ne(p),r.packageBaseUrl??=se(p)}r.indexURL=t,r.packageCacheDir&&(r.packageCacheDir=F(R(r.packageCacheDir)));let o={fullStdLib:!1,jsglobals:globalThis,stdin:globalThis.prompt?globalThis.prompt:void 0,args:[],env:{},packages:[],packageCacheDir:r.packageBaseUrl,enableRunUntilComplete:!0,checkAPIVersion:!0,BUILD_ID:"cc7a4bb4c6f36f12592fef0934292b5fddb0e313ca5dc4a5a9519bb7610c67e3"},n=Object.assign(o,r);n.env.HOME??="/home/pyodide",n.env.PYTHONINSPECT??="1";let i=ce(n),a=i.API;if(a.lockFilePromise=Promise.resolve(r.lockFileContents),typeof _createPyodideModule!="function"){let p=`${n.indexURL}pyodide.asm.js`;await O(p)}let l;if(e._loadSnapshot){let p=await e._loadSnapshot;ArrayBuffer.isView(p)?l=p:l=new Uint8Array(p),i.noInitialRun=!0,i.INITIAL_MEMORY=l.length}let u=await _createPyodideModule(i);if(i.exitCode!==void 0)throw new u.ExitStatus(i.exitCode);if(e.pyproxyToStringRepr&&a.setPyProxyToStringMethod(!0),e.convertNullToNone&&a.setCompatNullToNone(!0),a.version!==U&&n.checkAPIVersion)throw new Error(`Pyodide version does not match: '${U}' <==> '${a.version}'. If you updated the Pyodide version, make sure you also updated the 'indexURL' parameter passed to loadPyodide.`);u.locateFile=p=>{throw p.endsWith(".so")?new Error(`Failed to find dynamic library "${p}"`):new Error(`Unexpected call to locateFile("${p}")`)};let c;l&&(c=a.restoreSnapshot(l));let m=a.finalizeBootstrap(c,e._snapshotDeserializer);return a.sys.path.insert(0,""),a._pyodide.set_excepthook(),await a.packageIndexReady,a.initializeStreams(n.stdin,n.stdout,n.stderr),m}s(ge,"loadPyodide");class De{constructor(){this.pyodide=null,this.initPromise=null,this.isInitialized=!1,this.globalVariables={},this.variableCallbacks=new Set}async initialize(){return this.initPromise?this.initPromise:this.pyodide&&this.isInitialized?this.pyodide:(this.initPromise=this._doInitialize(),this.initPromise)}async _doInitialize(){try{return this.pyodide=await ge({indexURL:"https://cdn.jsdelivr.net/pyodide/v0.28.3/full/"}),await this.pyodide.loadPackage(["micropip"]),await this.pyodide.runPython(`
                import sys
                from io import StringIO
                import traceback
                
                class OutputCapture:
                    def __init__(self):
                        self.output = StringIO()
                        self.original_stdout = sys.stdout
                        self.original_stderr = sys.stderr
                    
                    def start_capture(self):
                        self.output = StringIO()
                        sys.stdout = self.output
                        sys.stderr = self.output
                    
                    def stop_capture(self):
                        sys.stdout = self.original_stdout
                        sys.stderr = self.original_stderr
                        result = self.output.getvalue()
                        self.output.close()
                        return result

                _output_capture = OutputCapture()
                
                # Global flag to track matplotlib loading state
                _matplotlib_loaded = False
                _matplotlib_loading = False
                
                async def ensure_matplotlib():
                    """Lazy load matplotlib only when needed"""
                    global _matplotlib_loaded, _matplotlib_loading
                    
                    if _matplotlib_loaded:
                        return True
                    
                    if _matplotlib_loading:
                        # Wait for ongoing load to complete
                        import asyncio
                        while _matplotlib_loading:
                            await asyncio.sleep(0.1)
                        return _matplotlib_loaded
                    
                    try:
                        _matplotlib_loading = True
                        print("📦 Loading matplotlib for plotting support...")
                        
                        # Check if matplotlib is already imported
                        if 'matplotlib' not in sys.modules:
                            import micropip
                            await micropip.install('matplotlib')
                        
                        import matplotlib
                        matplotlib.use('Agg')  # Use non-interactive backend
                        import matplotlib.pyplot as plt
                        import base64
                        from io import BytesIO
                        import warnings
                        
                        # Suppress the non-interactive backend warning
                        warnings.filterwarnings('ignore', message='.*non-interactive.*', category=UserWarning)
                        
                        # Store in globals for capture function
                        globals()['plt'] = plt
                        globals()['base64'] = base64
                        globals()['BytesIO'] = BytesIO
                        
                        _matplotlib_loaded = True
                        print("✅ Matplotlib ready for plotting!")
                        return True
                        
                    except Exception as e:
                        print(f"❌ Failed to load matplotlib: {e}")
                        return False
                    finally:
                        _matplotlib_loading = False
                
                def capture_matplotlib():
                    """Capture current matplotlib figure as base64 image"""
                    if not _matplotlib_loaded:
                        return ""
                    
                    try:
                        plt = globals().get('plt')
                        if plt and plt.get_fignums():  # Check if there are active figures
                            BytesIO = globals().get('BytesIO')
                            base64 = globals().get('base64')
                            
                            buf = BytesIO()
                            plt.savefig(buf, format='png', bbox_inches='tight', dpi=100)
                            buf.seek(0)
                            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
                            plt.close('all')  # Close all figures
                            return f"__MATPLOTLIB_IMG__{img_base64}__END_IMG__"
                    except Exception as e:
                        print(f"Warning: Failed to capture plot: {e}")
                    
                    return ""
                
                # Alternative: Support for lighter plotting libraries
                def capture_plotly():
                    """Capture Plotly figures if available"""
                    try:
                        import plotly.graph_objects as go
                        import plotly.io as pio
                        # Note: Plotly generates HTML/JS, not images
                        # This would need different handling in the UI
                        return ""
                    except ImportError:
                        return ""
                
                # Function to get user-defined variables
                def get_user_variables():
                    """Get user-defined variables with their types and values"""
                    import builtins
                    import types
                    import sys
                    
                    user_vars = {}
                    
                    try:
                        # Get current globals - avoid creating dict() which might cause JsProxy issues
                        current_globals = globals()
                        
                        # Built-in names to exclude
                        try:
                            builtin_names = set(dir(builtins))
                        except:
                            builtin_names = set()
                            
                        system_names = {
                            '__name__', '__doc__', '__package__', '__loader__', '__spec__',
                            '__annotations__', '__builtins__', '__file__', '__cached__',
                            'sys', 'traceback', 'StringIO', 'OutputCapture', '_output_capture',
                            '_matplotlib_loaded', '_matplotlib_loading', 'ensure_matplotlib',
                            'capture_matplotlib', 'capture_plotly', 'get_user_variables',
                            'plt', 'base64', 'BytesIO', '__user_code__', 'builtins', 'types'
                        }
                        
                        # Very defensive iteration over globals
                        try:
                            # Get keys as a list very carefully
                            keys_to_check = []
                            for key in current_globals:
                                try:
                                    # Ensure key is a string and safe to use
                                    if isinstance(key, str) and key not in system_names:
                                        keys_to_check.append(key)
                                except:
                                    continue
                        except:
                            # If we can't iterate, return empty
                            return {}
                        
                        # Process each key safely
                        for name in keys_to_check:
                            try:
                                # Skip system variables and built-ins
                                if (name.startswith('_') or 
                                    name in builtin_names or 
                                    name in system_names):
                                    continue
                                
                                # Get value very safely
                                try:
                                    value = current_globals[name]
                                except:
                                    continue
                                    
                                if value is None:
                                    continue
                                
                                # Skip modules and functions
                                try:
                                    if (isinstance(value, types.ModuleType) or
                                        callable(value)):
                                        continue
                                except:
                                    continue
                                
                                # Get type very safely
                                try:
                                    var_type = type(value).__name__
                                    # Skip problematic types immediately
                                    if var_type in ['JsProxy', 'JsMethod', 'JsBuffer', 'JsException']:
                                        continue
                                except:
                                    continue
                                
                                # Get string representation very safely
                                try:
                                    str_value = str(value)
                                    if len(str_value) > 100:
                                        str_value = str_value[:97] + '...'
                                    elif '\\n' in str_value:
                                        lines = str_value.split('\\n')
                                        str_value = lines[0] + ('...' if len(lines) > 1 else '')
                                except:
                                    str_value = f"<{var_type} object>"
                                
                                # Only add if we have valid string name
                                if isinstance(name, str) and name:
                                    user_vars[name] = {
                                        'type': var_type,
                                        'value': str_value
                                    }
                                
                            except Exception as e:
                                # Skip any variable that causes any error
                                continue
                        
                    except Exception as e:
                        # Return empty dict if there's any global error
                        return {}
                    
                    return user_vars
                
                # Check what's available
                import sys
                print(f"📦 Python {sys.version}")
                
                available_modules = ['micropip']
                for module in ['numpy', 'pandas']:
                    try:
                        __import__(module)
                        available_modules.append(module)
                    except ImportError:
                        pass
                
                print(f"📋 Pre-loaded modules: {available_modules}")
                print("✅ Ready for Python code execution!")
                print("💡 Tip: Import any package and get auto-install prompts from 250+ Pyodide packages!")
            `),this.isInitialized=!0,this.pyodide}catch(t){throw console.error("❌ Failed to initialize Pyodide:",t),this.pyodide=null,this.initPromise=null,this.isInitialized=!1,t}}async executeCode(t,r=null){const o=await this.initialize();if(!o)throw new Error("Pyodide not available");try{await o.runPython("_output_capture.start_capture()");let n="",i=null,a=!1,l=null;try{if((/\b(matplotlib|plt\.|pyplot)\b/.test(t)||/\bfrom\s+matplotlib/.test(t)||/\bimport\s+matplotlib/.test(t))&&(r&&r("📊 Loading matplotlib for plotting support... (first time may take a moment)"),await o.runPythonAsync("await ensure_matplotlib()"),r&&r("✅ Matplotlib ready - executing your code...")),/micropip\.install/.test(t)&&r){let y=[];const E=t.match(/micropip\.install\s*\(\s*['"`]([^'"`]+)['"`]\s*\)/g);E&&E.forEach(g=>{const B=g.match(/['"`]([^'"`]+)['"`]/)[1];y.push(B)});const _=t.match(/micropip\.install\s*\(\s*\[([^\]]+)\]\s*\)/g);if(_&&_.forEach(g=>{const be=g.match(/\[([^\]]+)\]/)[1].split(",").map(C=>C.trim().replace(/['"`]/g,"")).filter(C=>C);y=y.concat(be)}),y.length>0){const g=[...new Set(y)];g.length===1?r(`📦 Installing ${g[0]}... (this may take a moment)`):r(`📦 Installing ${g.length} packages: ${g.join(", ")}... (this may take a moment)`)}else r("📦 Installing packages... (this may take a moment)")}/\bawait\s+/.test(t)?await o.runPythonAsync(t):await o.runPython(t);const d=await o.runPython("capture_matplotlib()"),f=await o.runPython("_output_capture.stop_capture()");if(f&&f.includes("Traceback")){const y=f.split(`
`),E=y.find(_=>_.includes("Error:")||_.match(/^\w+Error:/)||_.match(/^\w+Exception:/));if(E)i=E.trim(),n="";else{const _=y.filter(g=>g.trim());_.length>0&&(i=_[_.length-1].trim(),n="")}}else d&&d.includes("__MATPLOTLIB_IMG__")&&(a=!0,l=d.replace("__MATPLOTLIB_IMG__","").replace("__END_IMG__","")),n=f;if(!n.trim()&&!a)try{const y=await o.runPython(`
import ast

# Parse the code to find the last expression
try:
    tree = ast.parse(__user_code__)
    if tree.body and isinstance(tree.body[-1], ast.Expr):
        # Last statement is an expression, evaluate it
        result = eval(compile(ast.Expression(tree.body[-1].value), '<string>', 'eval'))
        if result is not None:
            str(result)
        else:
            ""
    else:
        ""
except:
    ""
                        `);y&&(n=y)}catch{}}catch(c){let m="";try{m=await o.runPython("_output_capture.stop_capture()")}catch{}try{(c.message?.includes("RecursionError")||c.message?.includes("maximum recursion depth")||String(c).includes("RecursionError"))&&console.log("🔥 Recursion error detected - suggesting manual reset")}catch(d){console.log("⚠️ Error analysis failed:",d)}let p=c.message||String(c)||"Python execution failed";if(p.includes("PythonError:")&&(p=p.replace(/^.*PythonError:\s*/,"")),p==="PythonError"||p.trim()===""){const d=String(c),f=d.match(/(SyntaxError|NameError|IndentationError|TypeError|ValueError|AttributeError|ImportError|ModuleNotFoundError)[^:]*:.*$/m);f?p=f[0]:p=d||"Unknown Python error"}if(p.includes("ModuleNotFoundError")||p.includes("ImportError")){const d=p.match(/No module named '([^']+)'/);if(d){const f=d[1];["matplotlib","numpy","pandas"].includes(f)?p=`Module '${f}' should be available. Try reloading the page or check the exact import name.`:p=`Module '${f}' not found. Try installing it with:

import micropip
await micropip.install('${f}')`}}p?.includes("RecursionError")||p?.includes("maximum recursion depth")?i=`${p}

💡 Tip: Click the "🧹 Reset" button to completely restart the Python environment.`:i=p||"Python execution error",n=m}let u={};try{const c=await o.runPython("get_user_variables()");c&&typeof c=="object"?u=c.toJs?c.toJs():c:u={}}catch{u={}}return this.updateGlobalVariables(u),{output:n||null,error:i,hasPlot:a,plotData:l,userVariables:u}}catch(n){let i=n.message||"Unknown error",a={};try{const u=await(await this.initialize()).runPython("get_user_variables()");u&&typeof u=="object"?a=u.toJs?u.toJs():u:a={}}catch{a={}}return this.updateGlobalVariables(a),{output:null,error:i,hasPlot:!1,plotData:null,userVariables:a}}}async getUserVariables(){const t=await this.initialize();if(!t)return{};try{const r=await t.runPython("get_user_variables()");return r&&typeof r=="object"?r.toJs?r.toJs():r:{}}catch{return{}}}subscribeToVariables(t){return this.variableCallbacks.add(t),t(this.globalVariables),()=>{this.variableCallbacks.delete(t)}}updateGlobalVariables(t){this.globalVariables=t||{},this.variableCallbacks.forEach(r=>{try{r(this.globalVariables)}catch(o){console.error("Error in variable callback:",o)}})}getGlobalVariables(){return this.globalVariables}async resetEnvironment(){try{return this.pyodide=null,this.isInitialized=!1,this.initPromise=null,this.updateGlobalVariables({}),typeof window<"u"&&window.gc&&window.gc(),await this.initialize(),{error:null,hasPlot:!1,plotData:null}}catch(t){return{output:null,error:`Reset failed: ${t.message}. Try reloading the page.`,hasPlot:!1,plotData:null}}}warmUp(){!this.initPromise&&!this.isInitialized&&this.initialize().catch(t=>{console.log("Pre-warm failed, will try again when needed:",t.message)})}async cleanNamespace(t=!1){}async cleanup(){if(this.pyodide)try{this.pyodide=null,this.isInitialized=!1,this.initPromise=null}catch{return}}getStatus(){return this.isInitialized?"ready":this.initPromise?"initializing":"not-started"}}const Ce=new De;export{Ce as pyodideService};
